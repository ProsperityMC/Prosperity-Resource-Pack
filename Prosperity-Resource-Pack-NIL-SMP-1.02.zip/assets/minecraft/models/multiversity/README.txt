Models and textures from
https://www.planetminecraft.com/texture-pack/cad-bane-s-hat-pack-star-wars/

