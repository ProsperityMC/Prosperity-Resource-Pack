Models and textures from
https://www.curseforge.com/minecraft/texture-packs/tailored-hats

