Models and textures from
https://www.planetminecraft.com/texture-pack/custom-model-data-miscellaneous-hats-pack-d/

